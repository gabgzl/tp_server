#!/bin/bash
esLaborable_script="opt/tp/scripts/esLaborable.sh"
$esLaborable_script "$1"
