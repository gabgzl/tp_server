#!/bin/bash
#variables
hora=$(date "+%H:%M:%S")
fecha=$(date "+%Y%m%d")
directorio_origen="$1"
directorio_destino="/u03"
log_file="/var/log/backup_full.log"
#funcion para registrar eventos en el log
log() {
	echo "$hora - $1|$2" >> "$log_file"
}
#funcion para enviar el log por correo
enviar_log() {
	cat "$log_file" | mail -s "log de respaldo" root
}
#funcion para realizar el respaldo
hacer_backup() {
	local origen=$1
	local destino=$2
	local nombre=$(basename "$origen")
	local archivo_destino="$nombre"_bkp_"$fecha".tar.gz
	if [ -d "$origen" ]; then
		log "Comenzando respaldo de $nombre" "Exito"
		tar -czf "$destino/$archivodestino" -c "$origen"
		log "Respaldo de $nombre completado en $destino como $archivo_destino" "Exito"
	else
		log "Directorio $nombre no encontrado" "Error"
	fi
}
#validacion del directorio de destino
if [ "$directorio_destino" != "/u03" ]; then
	echo "El directorio de destino debe ser /u03"
	exit 1
fi
#manejo de argumentos
if [ "$#" -ne 1 ]; then
	echo "uso: $0 <directorio_origen>"
	exit 1
fi
#Realizar respaldos
case "$(date +%u)" in
	7) #domingo
	hacer_backup "$directorio_origen" "$directorio_destino"
	hacer_backup "$/u01" "$directorio_destino"
	hacer_backup "$u02" "$directorio_destino"
	;;
	*) #otros dias
	hacer_backup "$directorio_origen" "$directorio_destino"
	hacer_backup "$/var/log" "$directorio_destino"
	;;
esac
#enviar el log por correo al usuario root
enviar_log
exit 0
